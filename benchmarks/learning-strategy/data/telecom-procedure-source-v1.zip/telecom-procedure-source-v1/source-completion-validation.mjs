import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { checkFreeze, consumedCases, sourceFeedback, proposalRequest, SOURCE_RUN, STAGES } from "../benchmarks/learning-strategy/telecom/procedure-protocol.mjs";
import { hash, model, usageCost, priorExposure } from "../benchmarks/learning-strategy/telecom/provider.mjs";

const results = "benchmarks/learning-strategy/results";
const root = path.join(results, "telecom-procedure-source-v1");
const read = (base, name) => JSON.parse(fs.readFileSync(path.join(base, name), "utf8"));
assert.ok(fs.existsSync(path.join(root, "complete.json")));
assert.ok(!fs.existsSync(path.join(results, ".collector.lock")));
for (const [script, output] of [["procedure-audit.mjs", "audit.json"], ["procedure-analyze.mjs", "procedure-analysis.json"], ["procedure-review.mjs", null]]) {
  const r = spawnSync(process.execPath, ["benchmarks/learning-strategy/telecom/" + script, root], { encoding: "utf8", maxBuffer: 16000000 });
  process.stderr.write(r.stderr);
  if (r.status !== 0) { process.stdout.write(r.stdout); process.exit(r.status ?? 1); }
  if (output) fs.writeFileSync(path.join(root, output), r.stdout, { flag: "wx" });
  const a = JSON.parse(r.stdout);
  console.log(JSON.stringify({ script, status: a.status, calls: a.modelCalls, arms: a.arms, gate: a.advancementGate, spend: a.providerUsd ?? a.newPaidUsd }));
}
const discovery = path.join(results, "telecom-procedure-discovery-v4");
checkFreeze(discovery);
checkFreeze(root);
const feedback = sourceFeedback(path.join(results, SOURCE_RUN));
let discoveryUsd = 0;
for (const id of ["telecom-procedure-discovery-v2", "telecom-procedure-discovery-v3"]) {
  const dir = path.join(results, id), p = read(dir, "proposal.json"), raw = read(dir, `responses/${p.id}.json`);
  const ledger = fs.readFileSync(path.join(dir, "provider.jsonl"), "utf8").trim().split("\n").map(JSON.parse);
  assert.equal(ledger.length, 2);
  assert.equal(ledger[0].type, "intent"); assert.equal(ledger[1].type, "receipt");
  assert.equal(ledger[0].id, p.id); assert.equal(ledger[1].id, p.id);
  assert.equal(raw.status, 200); assert.equal(raw.response.model, model);
  assert.equal(hash(raw.request), ledger[0].promptHash);
  assert.deepEqual(raw.response.usage, ledger[1].usage);
  assert.equal(usageCost(raw.response.usage), ledger[1].usd);
  assert.equal(p.cost, ledger[1].usd);
  assert.equal(read(dir, "incomplete.json").provider.unresolved, 0);
  assert.deepEqual(JSON.parse(raw.response.content.filter(b => b.type === "text").map(b => b.text).join("\n")), p.edit);
  const expected = id.endsWith("v2") ? proposalRequest(feedback.map(r => r.feedback)) : read(dir, "repair-request.json");
  assert.deepEqual(raw.request, { model, max_tokens: 2048, ...expected });
  discoveryUsd += ledger[1].usd;
}
assert.equal(discoveryUsd, read(discovery, "complete.json").discoveryAllocationUsd);
const audit = read(root, "audit.json"), analysis = read(root, "procedure-analysis.json"), review = read(root, "procedure-review.json");
const trials = fs.readFileSync(path.join(root, "trial-data.jsonl"), "utf8").trim().split("\n").map(JSON.parse);
assert.equal(trials.length, 24);
assert.equal(trials.reduce((s, r) => s + r.modelCalls, 0), audit.modelCalls);
assert.equal(review.failedTrials.length, trials.filter(r => !r.passed).length);
assert.equal(hash(fs.readFileSync(path.join(root, review.exporterSnapshot), "utf8")), review.exporterSha256);
const consumed = consumedCases(results);
assert.ok([...STAGES.fresh.indices, ...STAGES.recipient.indices].every(i => !consumed.includes(i)));
const exposure = priorExposure(results), cumulative = exposure.reduce((s, r) => s + r.usd, 0);
assert.ok(Math.abs(cumulative - audit.cumulativeExposureUsd) < 1e-9);
const output = {
  status: "passed", episodes: trials.length, modelCalls: audit.modelCalls,
  discoveryCalls: 2, discoveryUsd, evaluationUsd: audit.providerUsd,
  studyUsd: discoveryUsd + audit.providerUsd, cumulativeExposureUsd: cumulative,
  sourceAndDiscoveryHashesUnchanged: true, exactProposalRequests: true,
  allTrialRowsReconciled: true, remainingPanelsUnconsumed: true,
  frozenSourceGate: analysis.advancementGate, productionActivation: false,
  preflight: read(".tmp", "procedure-preflight-validation.json"),
  validatorSource: "source-completion-validation.mjs",
  validatorSha256: hash(fs.readFileSync(new URL(import.meta.url), "utf8"))
};
fs.writeFileSync(path.join(root, output.validatorSource), fs.readFileSync(new URL(import.meta.url)), { flag: "wx" });
fs.writeFileSync(path.join(root, "completion-validation.json"), JSON.stringify(output, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(output));
