import { createHash, createPublicKey, verify } from "node:crypto";
import type { SkillEnvelope } from "./ingest.js";

/** Native Rust envelopes carry a raw 32-byte Ed25519 public key. */
export function verifySkillSignature(envelope: SkillEnvelope): boolean {
  try {
    const key = Buffer.from(envelope.author_pubkey, "base64");
    const signature = Buffer.from(envelope.signature, "base64");
    if (key.length !== 32 || signature.length !== 64) return false;
    const publicKey = createPublicKey({
      key: Buffer.concat([Buffer.from("302a300506032b6570032100", "hex"), key]),
      format: "der",
      type: "spki",
    });
    return verify(null, Buffer.from(envelope.skill_md, "base64"), publicKey, signature);
  } catch {
    return false;
  }
}

/** Run at every storage boundary, before deduplication or version mutation. */
export function validateSkillEnvelope(envelope: SkillEnvelope): string | null {
  if (!verifySkillSignature(envelope)) return "invalid Ed25519 signature";
  const actual = createHash("sha256")
    .update(Buffer.from(envelope.skill_md, "base64"))
    .digest("hex");
  return actual === envelope.content_hash ? null : "content hash mismatch";
}
