import { createBridge } from "./bridge.mjs";

export const ACTOR =
  "Resolve the customer's problem using the provided policy and tools. Diagnose from observations, follow prerequisites, obtain consent when required, and check the actual result before declaring success. You control account tools; ask the customer to operate their device. Keep each instruction clear. Use normal reasoning and tool calls.";
export const PROPOSER =
  "Improve a reusable troubleshooting strategy from observed execution evidence. Preserve sound behavior; avoid identities, phone numbers, task IDs, hidden answers and instance-specific scripts. Distinguish an actor failure from a simulator or interface failure. A successful repair is evidence for a procedure, not proof of transfer.";
export function actorContext(context, strategy) {
  return {
    system: [
      {
        type: "text",
        text: context.policy + "\n\n" + strategy,
        cache_control: { type: "ephemeral" },
      },
    ],
    tools: toTools(context.agentTools),
  };
}
function toTools(tools) {
  return tools.map(({ function: f }) => ({
    name: f.name,
    description: f.description,
    input_schema: f.parameters,
  }));
}
export function userContext(context) {
  return {
    system: [
      {
        type: "text",
        text:
          "Simulate the customer described below in a conversation with a support agent. Your assistant output is the customer's speech. Follow the scenario and persona. Do not solve the problem proactively: perform device actions only when the support agent asks. Use your tools to ground all reports of device state; never invent results. Your tools are private to you; the support agent sees only what you say. When the scenario's requested outcome is observed and you have no further requests, say goodbye and call end_conversation. If frustrated, follow the scenario rather than disclosing hidden information.\n\n" +
          JSON.stringify(context.userScenario),
        cache_control: { type: "ephemeral" },
      },
    ],
    tools: [
      ...toTools(context.userTools),
      {
        name: "end_conversation",
        description:
          "End this conversation after expressing your final response, when the issue is resolved or you explicitly give up.",
        input_schema: { type: "object", properties: {}, additionalProperties: false },
      },
    ],
  };
}

/** Role-separated conversation, real native tools, no grading feedback during play. */
export async function runEpisode({
  index,
  strategy = ACTOR,
  provider,
  tag,
  signal,
  onEvent = () => {},
  maxCalls = 96,
  maxUsd = 1.25,
}) {
  const bridge = createBridge(),
    started = performance.now();
  let usd = 0,
    toolCalls = 0,
    turns = 0,
    reason = "call-limit";
  const transcript = [],
    publicConversation = [];
  try {
    const context = await bridge.request({ method: "reset", index });
    if (context.history.length)
      throw Error("Initial conversation histories need an explicit adapter");
    const configs = { actor: actorContext(context, strategy), user: userContext(context) };
    const histories = {
      actor: [],
      user: [{ role: "user", content: "Support agent: Hi! How can I help you today?" }],
    };
    let seat = "user",
      done = false;
    for (; turns < maxCalls && !done; turns++) {
      signal?.throwIfAborted();
      let result;
      try {
        result = await provider.call(
          { ...configs[seat], messages: histories[seat] },
          { tag: `${tag}:${seat}:${turns}`, signal, localRemaining: maxUsd - usd },
        );
      } catch (error) {
        if (error.message === "Study provider ceiling reached") {
          reason = "budget-limit";
          break;
        }
        throw error;
      }
      usd += result.usd;
      transcript.push({ seat, id: result.id, content: result.content });
      onEvent({ type: "response", seat, id: result.id, turn: turns, usd: result.usd });
      if (result.stopReason === "max_tokens") {
        reason = "output-truncated";
        break;
      }
      histories[seat].push({ role: "assistant", content: result.content });
      const calls = result.content.filter((b) => b.type === "tool_use");
      const speech = result.content
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("\n")
        .trim();
      // As in native half-duplex tool interaction, text accompanying a tool call
      // stays private until that participant yields a speech-only response.
      if (calls.length) {
        const responses = [];
        for (const call of calls) {
          if (done) break;
          if (toolCalls >= 1000) {
            reason = "tool-limit";
            done = true;
            break;
          }
          if (seat === "user" && call.name === "end_conversation") {
            done = true;
            reason = "user-ended";
            responses.push({
              type: "tool_result",
              tool_use_id: call.id,
              content: "Conversation ended.",
            });
            if (speech) publicConversation.push({ seat, text: speech });
            continue;
          }
          const response = await bridge.request({
            method: "call",
            role: seat === "actor" ? "assistant" : "user",
            name: call.name,
            arguments: call.input,
          });
          toolCalls++;
          const event = { type: "tool", seat, name: call.name, arguments: call.input, ...response };
          transcript.push(event);
          onEvent(event);
          responses.push({
            type: "tool_result",
            tool_use_id: call.id,
            content: response.content,
            is_error: response.error,
          });
        }
        histories[seat].push({ role: "user", content: responses });
      } else if (speech) {
        publicConversation.push({ seat, text: speech });
        seat = seat === "actor" ? "user" : "actor";
        histories[seat].push({ role: "user", content: speech });
      } else {
        reason = "empty-response";
        break;
      }
    }
    const verdict = await bridge.request({ method: "judge" });
    return {
      verdict,
      reason,
      transcript,
      publicConversation,
      calls: turns,
      cost: { providerUsd: usd, toolCalls, wallMs: performance.now() - started },
    };
  } finally {
    bridge.close();
  }
}
