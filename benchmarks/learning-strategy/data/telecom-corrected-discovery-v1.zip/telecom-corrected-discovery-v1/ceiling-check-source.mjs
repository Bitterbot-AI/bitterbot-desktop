import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createBridge } from "../benchmarks/learning-strategy/telecom/bridge.mjs";
import { checkFreeze } from "../benchmarks/learning-strategy/telecom/procedure-protocol.mjs";
const root = path.resolve(process.argv[2]);
checkFreeze(root);
const read = (n) => JSON.parse(fs.readFileSync(path.join(root, n), "utf8"));
assert.equal(read("audit.json").status, "passed");
const targets = [
  { label: "experience-0-r1-case-36", index: 36 },
  { label: "experience-1-r1-case-44", index: 44 },
];
async function restore(target) {
  const original = read(`episode-${target.label}.json`),
    b = createBridge();
  try {
    await b.request({ method: "reset", index: target.index });
    for (const e of original.transcript.filter((t) => t.type === "tool")) {
      const result = await b.request({
        method: "call",
        role: e.seat === "actor" ? "assistant" : "user",
        name: e.name,
        arguments: e.arguments,
      });
      assert.equal(result.content, e.content);
      assert.equal(result.error, e.error);
    }
    assert.deepEqual(await b.request({ method: "judge" }), original.verdict);
    assert.equal(original.verdict.passed, false);
    return { b, original };
  } catch (error) {
    b.close();
    throw error;
  }
}
const rows = [];
for (const target of targets) {
  const { b, original } = await restore(target);
  let repairs, observations;
  try {
    const lookup = original.transcript.find(
      (t) => t.type === "tool" && t.seat === "actor" && t.name === "get_customer_by_phone",
    );
    assert.ok(lookup);
    const customer = JSON.parse(lookup.content);
    const observedLine = original.transcript
      .filter((t) => t.type === "tool" && t.seat === "actor" && t.name === "get_details_by_id")
      .map((t) => JSON.parse(t.content))
      .find((t) => t.line_id && t.phone_number === lookup.arguments.phone_number);
    assert.ok(observedLine, "Use the line binding actually observed in the trajectory");
    const calls = [
      { role: "assistant", name: "get_details_by_id", arguments: { id: observedLine.line_id } },
      { role: "assistant", name: "get_details_by_id", arguments: { id: observedLine.plan_id } },
      { role: "user", name: "check_network_status", arguments: {} },
    ];
    observations = [];
    for (const call of calls) {
      const result = await b.request({ method: "call", ...call });
      assert.equal(result.error, false);
      observations.push({ ...call, result });
    }
    const line = JSON.parse(observations[0].result.content),
      plan = JSON.parse(observations[1].result.content),
      network = observations[2].result.content;
    assert.ok(
      line.data_used_gb < plan.data_limit_gb + line.data_refueling_gb,
      "This check tests roaming only, no purchases",
    );
    repairs = [];
    if (!line.roaming_enabled)
      repairs.push({
        role: "assistant",
        name: "enable_roaming",
        arguments: { customer_id: customer.customer_id, line_id: line.line_id },
      });
    if (/^Data Roaming Enabled: No$/m.test(network))
      repairs.push({ role: "user", name: "toggle_roaming", arguments: {} });
    assert.ok(repairs.length > 0);
  } finally {
    b.close();
  }
  const variants = [];
  for (const omit of [-1, ...repairs.map((_, i) => i)]) {
    const { b } = await restore(target);
    try {
      const actions = [];
      for (const [i, call] of repairs.entries()) {
        if (i === omit) continue;
        const result = await b.request({ method: "call", ...call });
        assert.equal(result.error, false);
        actions.push({ ...call, result });
      }
      const verdict = await b.request({ method: "judge" });
      assert.equal(verdict.replayMatch, true);
      assert.equal(verdict.unrelatedPreserved, true);
      variants.push({ omittedRepair: omit, actions, verdict });
    } finally {
      b.close();
    }
  }
  rows.push({ ...target, observations, repairs, variants });
}
const full = rows.map((r) => r.variants[0]),
  negative = rows.flatMap((r) => r.variants.slice(1));
const source = fs.readFileSync(fileURLToPath(import.meta.url));
const result = {
  status: "completed-host-diagnostic",
  purpose:
    "Check two exact parent states that the engineers described as potentially unresolvable. Use the earlier host-authored roaming hypothesis, public observed bindings, native queries and single-omission controls on isolated replays.",
  originalOutcomesUnchanged: true,
  newProviderCalls: 0,
  learningBenefitEstablished: false,
  limitation:
    "Host-guided post-collection mechanism check. No model selected these actions and no new consent conversation was evaluated. This does not replace the support episodes or measure autonomous/recipient benefit.",
  sourceHash: createHash("sha256").update(source).digest("hex"),
  fullRepairs: full.filter((r) => r.verdict.passed).length,
  states: rows.length,
  singleOmissionFailures: negative.filter((r) => !r.verdict.passed).length,
  singleOmissionControls: negative.length,
  rows,
};
fs.writeFileSync(path.join(root, "ceiling-check-source.mjs"), source, { flag: "wx" });
fs.writeFileSync(path.join(root, "ceiling-check.json"), JSON.stringify(result, null, 2) + "\n", {
  flag: "wx",
});
console.log(JSON.stringify({ ...result, rows: undefined }));
