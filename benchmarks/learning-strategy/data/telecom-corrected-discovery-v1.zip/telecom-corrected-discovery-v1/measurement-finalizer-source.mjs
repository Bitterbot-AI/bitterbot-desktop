import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(process.argv[2]),
  id = path.basename(root);
const read = (n) => JSON.parse(fs.readFileSync(path.join(root, n), "utf8"));
const hash = (n) =>
  createHash("sha256")
    .update(fs.readFileSync(path.join(root, n)))
    .digest("hex");
assert.equal(read("protocol.json").stage, "discovery");
assert.equal(read("audit.json").status, "passed");
const packet = read("measurement-review-packet.json"),
  analysis = read("analysis.json");
const reviews = ["purchase", "service"].flatMap((kind) =>
  JSON.parse(fs.readFileSync(path.join(".tmp", `${id}-${kind}-reviews.json`), "utf8")),
);
assert.equal(reviews.length, 72);
assert.equal(new Set(reviews.map((r) => r.label)).size, 72);
assert.equal(packet.episodes.length, 72);
for (const e of packet.episodes) {
  const review = reviews.find((r) => r.label === e.label);
  assert.equal(review?.measurementAligned, true);
  assert.equal(review.episodeHash, hash(`episode-${e.label}.json`));
  assert.equal(review.purchases, e.refuels.length);
  assert.ok(["user-ended", "human-transfer"].includes(e.termination));
  assert.equal(
    e.interfaceFailures.length,
    0,
    "Interface exception requires explicit additional review",
  );
}
const result = {
  status: "passed",
  run: id,
  stage: "discovery",
  meaning:
    "Targeted outcome/consent measurement review, not an efficacy gate or complete policy-compliance certification.",
  method:
    "Manually reviewed all 72 final customer service reports against native criteria and every actual purchase's preceding public quantity/price offer and explicit approval. Full conversations remain in the packet for inspection. Per-episode reviewed-byte hashes are checked after cold replay. Native outcomes and selections are unchanged.",
  auditHash: hash("audit.json"),
  analysisHash: hash("analysis.json"),
  completeHash: hash("complete.json"),
  packetHash: hash("measurement-review-packet.json"),
  episodes: reviews,
  repairs: analysis.rows.filter((r) => r.passed).length,
  purchases: reviews.reduce((s, r) => s + r.purchases, 0),
  quantityConsentGradeConflicts: 0,
  newProviderCalls: 0,
  originalOutcomesUnchanged: true,
  limitations: [
    "Synthetic amended customer scenario; not official benchmark parity or real-user efficacy.",
    "Targeted review is performed by the research agent, not a blinded independent annotator.",
  ],
};
const bytes = fs.readFileSync(fileURLToPath(import.meta.url));
fs.writeFileSync(path.join(root, "measurement-finalizer-source.mjs"), bytes, { flag: "wx" });
fs.writeFileSync(
  path.join(root, "measurement-review.json"),
  JSON.stringify(result, null, 2) + "\n",
  { flag: "wx" },
);
console.log(
  JSON.stringify({
    status: result.status,
    episodes: reviews.length,
    purchases: result.purchases,
    conflicts: 0,
  }),
);
