import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.resolve(process.argv[2]);
const read = (n) => JSON.parse(fs.readFileSync(path.join(root, n), "utf8"));
assert.equal(read("audit.json").status, "passed");
assert.equal(read("protocol.json").stage, "discovery");
const complete = read("complete.json"),
  analysis = read("analysis.json");
const proposals = complete.proposalLabels.map((l) => read(`proposal-${l}.json`));
const attempts = proposals.flatMap((p) => p.programAttempts.map((a) => ({ label: p.label, ...a })));
const probes = proposals.flatMap((p) =>
  p.probeResults.filter((r) => r.case).map((r) => ({ label: p.label, ...r })),
);
const traces = proposals.flatMap((p) =>
  typeof p.packet.evidence === "object"
    ? p.packet.evidence.traces.map((r) => ({ label: p.label, ...r }))
    : [],
);
const omitted = proposals.flatMap((p) =>
  typeof p.packet.evidence === "object"
    ? p.packet.evidence.omitted.map((r) => ({ label: p.label, ...r }))
    : [],
);
const result = {
  status: "completed-postcollection-diagnostics",
  newProviderCalls: 0,
  originalOutcomesUnchanged: true,
  compiler: {
    proposals: proposals.length,
    initialValid: proposals.filter((p) => p.programAttempts[0].generated.valid).length,
    repairAttempts: proposals.filter((p) => p.programAttempts.length === 2).length,
    repaired: proposals.filter((p) => p.programAttempts.length === 2 && p.generated.valid).length,
    finalValid: proposals.filter((p) => p.generated.valid).length,
    totalAttempts: attempts.length,
  },
  deliveries: proposals.map((p) => ({
    label: p.label,
    delivery: p.generated.program?.delivery ?? null,
    valid: p.generated.valid,
    attempts: p.programAttempts.length,
    assessment: p.generated.assessment ?? null,
  })),
  probes: {
    attempted: probes.length,
    errors: probes.filter((p) => p.error).length,
    completed: probes.filter((p) => !p.error).length,
    failedStateProbes: probes.filter((p) => p.beforePassed === false).length,
    failedStatesRepaired: probes.filter((p) => p.beforePassed === false && p.afterPassed === true)
      .length,
    passingStatesBroken: probes.filter((p) => p.beforePassed === true && p.afterPassed === false)
      .length,
    records: probes,
  },
  evidence: {
    tracesSupplied: traces.length,
    failedTracesSupplied: traces.filter((t) => !t.passed).length,
    truncated: traces.filter((t) => t.traceTruncated).length,
    omitted,
  },
  identicalProgramGroups: [
    ...new Set(proposals.filter((p) => p.generated.valid).map((p) => p.generated.actor)),
  ].map((actor) => ({
    actorHash: createHash("sha256").update(actor).digest("hex"),
    proposals: proposals.filter((p) => p.generated.actor === actor).map((p) => p.label),
  })),
  behaviorGroups: [true, false].map((valid) => {
    const labels = new Set(
      proposals.filter((p) => p.generated.valid === valid).map((p) => p.label),
    );
    const rows = analysis.rows.filter((r) =>
      [...labels].some((l) => r.label.startsWith(l + "-case-")),
    );
    return {
      valid,
      proposals: labels.size,
      episodes: rows.length,
      repairs: rows.filter((r) => r.passed).length,
    };
  }),
};
const bytes = fs.readFileSync(fileURLToPath(import.meta.url));
result.sourceHash = createHash("sha256").update(bytes).digest("hex");
fs.writeFileSync(path.join(root, "discovery-diagnostics-source.mjs"), bytes, { flag: "wx" });
fs.writeFileSync(
  path.join(root, "discovery-diagnostics.json"),
  JSON.stringify(result, null, 2) + "\n",
  { flag: "wx" },
);
console.log(
  JSON.stringify(
    {
      compiler: result.compiler,
      evidence: result.evidence,
      probes: { ...result.probes, records: undefined },
      groups: result.behaviorGroups,
    },
    null,
    2,
  ),
);
