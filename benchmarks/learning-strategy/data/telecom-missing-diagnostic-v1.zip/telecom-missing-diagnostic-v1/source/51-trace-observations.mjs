import { customerGroundingIssue } from "./grounding.mjs";

/** Replay observations, not decisions: recorded actions never change in this diagnostic.
 * Customer tool results and text accompanying tools are private. Final goodbye
 * speech never triggers a new actor call. Preserve the live loop's boundaries.
 */
export function routeRecordedObservations(episode, host, scenario, guard = true) {
  const hits = [];
  let groundingFailure = null;
  for (const [position, row] of episode.transcript.entries()) {
    if (row.type === "tool") {
      if (row.seat !== "actor") continue;
      host.actorTool(row, `tool-${position}`);
      if (row.name === "transfer_to_human_agents" && !row.error) break;
      continue;
    }
    if (!row.id) continue;
    if (row.seat === "actor") {
      const matches = host.take();
      if (matches.length) hits.push({ beforeTranscriptPosition: position, matches });
    }
    const calls = row.content.filter((part) => part.type === "tool_use");
    const speech = row.content
      .filter((part) => part.type === "text")
      .map((part) => part.text)
      .join("\n")
      .trim();
    const terminal = row.seat === "user" && calls.some((call) => call.name === "end_conversation");
    if (guard && row.seat === "user" && speech && (!calls.length || terminal)) {
      const issue = customerGroundingIssue(scenario, speech);
      if (issue) {
        groundingFailure = { position, responseId: row.id, issue };
        break;
      }
    }
    if (terminal) break;
    if (calls.length || !speech) continue;
    if (row.seat === "actor") host.actorSpeech(speech);
    else host.customerSpeech(speech, `speech-${position}`);
  }
  return { hits, groundingFailure };
}
