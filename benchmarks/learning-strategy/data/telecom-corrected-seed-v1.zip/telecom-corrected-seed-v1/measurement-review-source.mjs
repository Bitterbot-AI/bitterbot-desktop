import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  checkFreeze,
  consumedCases,
} from "../benchmarks/learning-strategy/telecom/procedure-protocol.mjs";

// Read-only post-collection packet. Human/agent review remains explicit, never a lexical consent oracle.
const root = path.resolve(process.argv[2]);
const read = (n) => JSON.parse(fs.readFileSync(path.join(root, n), "utf8"));
const sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
checkFreeze(root);
const protocol = read("protocol.json"),
  audit = read("audit.json"),
  analysis = read("analysis.json");
assert.equal(audit.status, "passed");
assert.equal(analysis.status, "passed");
const consumed = new Set(consumedCases(path.dirname(root)));
assert.ok(protocol.indices.every((i) => consumed.has(i)));
const datasetBytes = fs.readFileSync(
  "benchmarks/learning-strategy/datasets/tau-bench-v2-en/upstream/data/tau2/multilingual/en/telecom_tasks_en.json",
);
const tasks = JSON.parse(datasetBytes);
const episodes = analysis.rows.map((row) => {
  const e = read(`episode-${row.label}.json`);
  const criteria = tasks[row.index].evaluation_criteria.env_assertions;
  assert.equal(criteria.length, e.verdict.checks.length);
  const refuels = e.transcript.flatMap((t, position) => {
    if (t.type !== "tool" || t.name !== "refuel_data") return [];
    const prior = e.transcript
      .slice(0, position)
      .filter((r) => r.seat === "actor" && r.id)
      .at(-1);
    const call = prior?.content.find(
      (b) =>
        b.type === "tool_use" &&
        b.name === "refuel_data" &&
        JSON.stringify(b.input) === JSON.stringify(t.arguments),
    );
    assert.ok(call, "Preserve actual purchase arguments");
    const precedingPublicDialogue = e.transcript
      .slice(0, position)
      .flatMap((r, at) => {
        if (r.type === "public-observations") return [{ at, seat: "user", text: r.speech }];
        if (r.seat === "actor" && r.id && !r.content.some((b) => b.type === "tool_use")) {
          const text = r.content
            .filter((b) => b.type === "text")
            .map((b) => b.text)
            .join("\n")
            .trim();
          return text ? [{ at, seat: "actor", text }] : [];
        }
        return [];
      })
      .slice(-8);
    return [
      {
        position,
        arguments: t.arguments,
        result: t.content,
        error: t.error ?? null,
        precedingPublicDialogue,
      },
    ];
  });
  return {
    label: row.label,
    index: row.index,
    passed: row.passed,
    termination: row.termination,
    nativeChecks: criteria.map((c, i) => ({
      name: c.func_name,
      arguments: c.arguments,
      passed: e.verdict.checks[i],
    })),
    refuels,
    publicConversation: e.publicConversation,
    interfaceFailures: e.transcript.filter((t) =>
      ["observation-failure", "grounding"].includes(t.type),
    ),
    publicationRecoveries: e.publicationRecoveries,
  };
});
const sourceBytes = fs.readFileSync(fileURLToPath(import.meta.url));
const output = {
  run: path.basename(root),
  stage: protocol.stage,
  method:
    "All complete public conversations, native purchase arguments/results and criterion-level grades exported for explicit review. No automated consent classification or rescoring.",
  newProviderCalls: 0,
  originalOutcomesUnchanged: true,
  auditHash: sha(fs.readFileSync(path.join(root, "audit.json"))),
  analysisHash: sha(fs.readFileSync(path.join(root, "analysis.json"))),
  datasetHash: sha(datasetBytes),
  sourceHash: sha(sourceBytes),
  episodes,
};
fs.writeFileSync(path.join(root, "measurement-review-source.mjs"), sourceBytes, { flag: "wx" });
fs.writeFileSync(
  path.join(root, "measurement-review-packet.json"),
  JSON.stringify(output, null, 2) + "\n",
  { flag: "wx" },
);
console.log(
  JSON.stringify({
    run: output.run,
    episodes: episodes.length,
    repairs: episodes.filter((e) => e.passed).length,
    quantityFailures: episodes
      .filter((e) =>
        e.nativeChecks.some((c) => c.name === "assert_data_refueling_amount" && !c.passed),
      )
      .map((e) => e.label),
    purchases: episodes.filter((e) => e.refuels.length).map((e) => e.label),
  }),
);
